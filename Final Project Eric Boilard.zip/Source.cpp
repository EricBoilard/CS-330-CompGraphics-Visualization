#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

// GLM MATH
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Image loading libraries
#include <SOIL2/SOIL2.h>          
//#define STB_IMAGE_IMPLEMENTATION
//#include <stb/stb_image.h> 

using namespace std; 

//--------------------------------------------------------------------------------------------------------------------------------------

void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

int main(void);

glm::vec3 cameraPos = glm::vec3(0.0f, 3.0f, 6.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 3.0f, 0.0f);

bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 1080.0f / 2.0;
float lastY = 720.0 / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

// light source position
glm::vec3 lightPosition(15.0f, -25.0f, 0.0f);

void draw() {
    GLenum mode = GL_TRIANGLES;
    GLint first = 0;
    GLsizei count = 45;

    glDrawArrays(mode, first, count);
}

//--------------------------------------------------------------------------------------------------------------------------------------

/* Create and compile shaders */
static GLuint CompileShader(const string& source, GLuint shaderType) {
    // shader object
    GLuint shaderID = glCreateShader(shaderType);
    const char* src = source.c_str();

    // attach source code to the shader object
    glShaderSource(shaderID, 1, &src, nullptr);

    // compile shader
    glCompileShader(shaderID);

    // return the ID of compiled shader
    return shaderID;
}

//--------------------------------------------------------------------------------------------------------------------------------------

/* Create program object */
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader) {
    // compile vertex shader
    GLuint vertexShaderComp = CompileShader(vertexShader, GL_VERTEX_SHADER);

    // compile fragment shader
    GLuint fragmentShaderComp = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

    // create a program object
    GLuint shaderProgram = glCreateProgram();

    // Attach vertex and fragment shaders to program object
    glAttachShader(shaderProgram, vertexShaderComp);
    glAttachShader(shaderProgram, fragmentShaderComp);

    // link shader to create executable
    glLinkProgram(shaderProgram);

    // Delete shaders
    glDeleteShader(vertexShaderComp);
    glDeleteShader(fragmentShaderComp);

    // return shader program
    return shaderProgram;
}
//--------------------------------------------------------------------------------------------------------------------------------------

// Process all input
void processInput(GLFWwindow* window) {

    //const float cameraSpeed = 0.05f; // adjust accordingly

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) // if escape key is pressed the opengl window closes
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = 2.5 * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    //else if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
}

//--------------------------------------------------------------------------------------------------------------------------------------

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(2160, 1080, "Main Window", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetCursorPosCallback(window, mouse_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    /* Initialize GLEW */
    if (glewInit() != GLEW_OK)
        cout << "Error!" << endl;

    //--------------------------------------------------------------------------------------------------------------------------------------

    GLfloat lampVertices[] = {

       -0.5f,-0.5f,-0.5f,
        0.5f,-0.5f,-0.5f,
        0.0f, 0.5f, 0.0f,

       -0.5f,-0.5f, 0.5f,
        0.5f,-0.5f, 0.5f,
        0.0f, 0.5f, 0.0f,

       -0.5f,-0.5f,-0.5f,
       -0.5f,-0.5f, 0.5f,
        0.0f, 0.5f, 0.0f,

        0.5f,-0.5f,-0.5f,
        0.5f,-0.5f, 0.5f,
        0.0f, 0.5f, 0.0f,

        0.5f,-0.5f,-0.5f,
        0.5f,-0.5f, 0.5f,
       -0.5f,-0.5f,-0.5f,

       -0.5f,-0.5f, 0.5f,
       -0.5f,-0.5f,-0.5f,
        0.5f,-0.5f, 0.5f

    };

    GLfloat cheeseVertices[] = {  /* creating a vertex array to store our x, y, and z positions */

       // bottom of cheese
        -1.5f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,   1.0, 1.0, 1.0,
        -1.0f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,   1.0, 1.0, 1.0,
        -1.0f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,   1.0, 1.0, 1.0,
         
        -1.0f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,   1.0, 1.0, 1.0,
        -1.5f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,   1.0, 1.0, 1.0,
        -1.5f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,   1.0, 1.0, 1.0,

        // top of cheese
        -1.5f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,   1.0, 1.0, 1.0,
        -1.0f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,   1.0, 1.0, 1.0,
        -1.0f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

        -1.0f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.5f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.5f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,

        // front of cheese
        -1.5f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

        -1.0f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.5f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.5f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,

        // right side cheese
        -1.0f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

        -1.0f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.2f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        -1.0f, 0.0f, 1.0f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,

        // back of cheese
       -1.0f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
       -1.5f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,
       -1.5f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

       -1.5f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
       -1.0f, 0.2f, 0.7f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
       -1.0f, 0.0f, 0.7f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,

       // left side cheese
      -1.5f, 0.0f, 0.7f,    1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
      -1.5f, 0.0f, 1.0f,    1.0f, 1.0f, 1.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,
      -1.5f, 0.2f, 1.0f,    1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

      -1.5f, 0.2f, 1.0f,    1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
      -1.5f, 0.2f, 0.7f,    1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
      -1.5f, 0.0f, 0.7f,    1.0f, 1.0f, 1.0f,   0.0f, 0.0f,   1.0, 1.0, 1.0

    };

    GLfloat sphereVerts[] = {

        -0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,   1.0, 1.0, 1.0,
        0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        0.0f, 0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,

       -0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
        0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        0.0f, 0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,

       -0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.5f, 0.5f,  1.0, 1.0, 1.0,
       -0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
        0.0f, 0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,

        0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.5f, 0.5f,  1.0, 1.0, 1.0,
        0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
        0.0f, 0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,

        0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.5f, 0.5f,  1.0, 1.0, 1.0,
        0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
       -0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,

       -0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.5f, 0.5f,  1.0, 1.0, 1.0,
       -0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
        0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0
    };

    GLfloat boardVertices[] = {  /* creating a vertex array to store our x, y, and z positions */

       // top of cutting board
        -2.0f, 0.0f,  1.4f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0,
         2.0f, 0.0f,  1.4f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,  1.0, 1.0, 1.0,
         2.0f, 0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,

         2.0f, 0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.0f,  1.4f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,  1.0, 1.0, 1.0

        /*
        // top of cutting board
        -2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
         2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,
         2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,

         2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,
        -2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
        -2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,

        // front of cutting board
        -2.0f,  0.0f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
         2.0f,  0.0f,  1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,
         2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,

         2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,
        -2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
        -2.0f,  0.0f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,

        // right side cutting board
         2.0f,  0.0f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
         2.0f,  0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,
         2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,

         2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,
         2.0f, -0.2f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
         2.0f,  0.0f,  1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,

         // back of cutting board
         2.0f,  0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
        -2.0f,  0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 0.0f,
        -2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,

        -2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   1.0f, 1.0f,
         2.0f, -0.2f, -1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
         2.0f,  0.0f, -1.2f,     1.0f, 1.0f, 1.0f,   0.0f, 0.0f,

         // lfet side of cutting board
        -2.0f,  0.0f, -1.2f,    1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
        -2.0f,  0.0f,  1.2f,    1.0f, 1.0f, 1.0f,   1.0f, 0.0f,
        -2.0f, -0.2f,  1.2f,    1.0f, 1.0f, 1.0f,   1.0f, 1.0f,

        -2.0f, -0.2f,  1.2f,    1.0f, 1.0f, 1.0f,   1.0f, 1.0f,
        -2.0f, -0.2f, -1.2f,    1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
        -2.0f,  0.0f, -1.2f,    1.0f, 1.0f, 1.0f,   0.0f, 0.0f
        */
    };

    GLfloat cucumberVertices[] = {

        0.0f,  0.0f, 0.0f,      0.0f, 1.0f, 0.0f,    1.0f, 1.0f,   1.0, 1.0, 1.0,
       -0.33f, 1.0f, 0.0f,      0.0f, 1.0f, 0.0f,    0.0f, 0.0f,  1.0, 1.0, 1.0,
        0.33f, 1.0f, 0.0f,      0.0f, 1.0f, 0.0f,    0.0f, 1.0f,  1.0, 1.0, 1.0,

        0.0f,  0.0f, -6.0f,     0.0f, 1.0f, 0.0f,    1.0f, 1.0f,  1.0, 1.0, 1.0,
       -0.33f, 1.0f, -6.0f,     0.0f, 1.0f, 0.0f,    0.0f, 0.0f,  1.0, 1.0, 1.0,
        0.33f, 1.0f, -6.0f,     0.0f, 1.0f, 0.0f,    0.0f, 1.0f,  1.0, 1.0, 1.0

    };

    GLfloat cucumberSkinVert[] = {

       -0.33f, 1.0f, -6.0f,      0.0f, 1.0f, 0.0f,    0.0f, 0.0f,  1.0, 1.0, 1.0,
       -0.33f, 1.0f, 0.0f,       0.0f, 1.0f, 0.0f,    0.0f, 1.0f,  1.0, 1.0, 1.0,
        0.33f, 1.0f, 0.0f,       0.0f, 1.0f, 0.0f,    1.0f, 1.0f,  1.0, 1.0, 1.0,

        0.33f, 1.0f, 0.0f,       0.0f, 1.0f, 0.0f,    0.0f, 1.0f,  1.0, 1.0, 1.0,
        0.33f, 1.0f, -6.0f,      0.0f, 1.0f, 0.0f,    0.0f, 0.0f,  1.0, 1.0, 1.0,
       -0.33f, 1.0f, -6.0f,      0.0f, 1.0f, 0.0f,    1.0f, 1.0f,  1.0, 1.0, 1.0

    };

    GLfloat knifeHandleVerts[] = {

        // front then back
        -2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,  0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,  1.0f, 1.0f,  1.0, 1.0, 1.0,
         2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  1.0, 1.0, 1.0,

         2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,  0.0f, 0.0f,  1.0, 1.0, 1.0,
         2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,  1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, -0.5f,      0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  1.0, 1.0, 1.0,
         2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f, 1.0f, 1.0f,  1.0, 1.0, 1.0,

         2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
         2.0f, 0.25f, -0.5f,      0.0f, 1.0f, 0.0f, 1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, -0.5f,      0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  1.0, 1.0, 1.0,

        //left and right
        -2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,

        2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0,
        2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0,

        2.0f, -0.25f, 0.5f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0,
        2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0,

        // top then bottom
       -2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,       0.0f, 0.0f,  1.0, 1.0, 1.0,
       -2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0,
        2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0,

        2.0f, 0.25f, 0.5f,      0.0f, 1.0f, 0.0f,       0.0f, 0.0f,  1.0, 1.0, 1.0,
        2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0,
       -2.0f, 0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0,

       -2.0f, -0.25f, 0.5f,      0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
       -2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
        2.0f, -0.25f, 0.5f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,

        2.0f, -0.25f, 0.5f,      0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0, 
        2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
       -2.0f, -0.25f, -0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0

    };


    GLfloat knifeBladeVerts[] = {

        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.1f, 0.20f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.1f, -0.40f,    0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.1f, -0.40f,    0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.1f, -0.40f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, 0.1f, -0.40f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
        -8.0f, 0.0f, -0.40f,     0.0f, 1.0f, 0.0f,      1.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        -8.0f, 0.0f, -0.40f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.1f, -0.40f,     0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -8.0f, -0.0f, -0.40f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, -0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
        -8.0f, -0.0f, -0.40f,     0.0f, 1.0f, 0.0f,     1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.1f, 0.20f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.0f, 0.40f,      0.0f, 1.0f, 0.0f,     1.0f, 1.0f,  1.0, 1.0, 1.0,

        -6.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, -0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 0.0f,  1.0, 1.0, 1.0,
        -6.0f, 0.0f, 0.40f,     0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0,

        -6.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0, 
        -6.0f, 0.0f, 0.40f,     0.0f, 1.0f, 0.0f,       0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.0f, 0.40f,      0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, 0.0f, 0.40f,      0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,

        -6.0f, -0.1f, 0.20f,      0.0f, 1.0f, 0.0f,     0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, 0.0f, 0.40f,     0.0f, 1.0f, 0.0f,       0.0f, 0.0f,  1.0, 1.0, 1.0,
        -2.0f, 0.0f, 0.40f,      0.0f, 1.0f, 0.0f,      1.0f, 0.0f,  1.0, 1.0, 1.0,

        -2.0f, 0.0f, 0.40f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f, -0.1f, 0.20f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
        -6.0f, -0.1f, 0.20f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -6.0f, 0.1f, 0.20f,      0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
         -6.0f, 0.0f, 0.40f,     0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
         -8.0f, -0.0f, -0.40f,   0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -6.0f, -0.1f, 0.20f,    0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  1.0, 1.0, 1.0,
        -6.0f, 0.0f, 0.40f,    0.0f, 1.0f, 0.0f,        0.0f, 0.0f,  1.0, 1.0, 1.0,
        -8.0f, -0.0f, -0.40f,    0.0f, 1.0f, 0.0f,      1.0f, 1.0f,  1.0, 1.0, 1.0,

        -2.0f, -0.1f, -0.40f,    0.0f, 1.0f, 0.0f,      0.0f, 1.0f,  1.0, 1.0, 1.0,
        -2.0f,  0.1f, -0.40f,    0.0f, 1.0f, 0.0f,      0.0f, 0.0f,  1.0, 1.0, 1.0,
         -8.0f, -0.0f, -0.40f,   0.0f, 1.0f, 0.0f,       1.0f, 1.0f,  1.0, 1.0, 1.0

    };

    GLfloat leafVerts[]{

        1.0f, 0.0f, 0.0f,     0.0f, 1.0f, 0.0f,        1.0f, 0.0f,  1.0, 1.0, 1.0,
        0.0f, 1.0f, 0.0f,     0.0f, 1.0f, 0.0f,        0.0f, 0.5f,  1.0, 1.0, 1.0,
        0.0f, 0.0f, 0.0f,     0.0f, 1.0f, 0.0f,        0.0f, 0.0f,   1.0, 1.0, 1.0

    };

    //--------------------------------------------------------------------------------------------------------------------------------------
    // creating vertex buffer objects and vertex array objects to establish contents of each object

    GLuint cheeseVBO, cheeseVAO, boardVBO, boardVAO, cucumberVBO, cucumberVAO, cucumberSkinVBO, cucumberSkinVAO, knifeHandleVBO, knifeHandleVAO, knifeBladeVBO, knifeBladeVAO, sphereVBO, sphereVAO, leafVBO, leafVAO; // Vertex vuffer object gets vertices on screen, EBO gets elements on screen for indices, VAO acts as a container for VBO and EBO

    glGenBuffers(1, &cheeseVBO); // Create vertex buffer object
    glGenBuffers(1, &boardVBO);
    glGenBuffers(1, &cucumberVBO);
    glGenBuffers(1, &cucumberSkinVBO);
    glGenBuffers(1, &knifeHandleVBO);
    glGenBuffers(1, &knifeBladeVBO);
    glGenBuffers(1, &sphereVBO);
    glGenBuffers(1, &leafVBO);

    glGenVertexArrays(1, &cheeseVAO); // Create our vertex array object which acts as a container for EBO and VBO
    glGenVertexArrays(1, &boardVAO);
    glGenVertexArrays(1, &cucumberVAO);
    glGenVertexArrays(1, &cucumberSkinVAO);
    glGenVertexArrays(1, &knifeHandleVAO);
    glGenVertexArrays(1, &knifeBladeVAO);
    glGenVertexArrays(1, &sphereVAO);
    glGenVertexArrays(1, &leafVAO);

    //-------------------------------------------------------

    glBindVertexArray(cheeseVAO); // select our VAO

    glBindBuffer(GL_ARRAY_BUFFER, cheeseVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(cheeseVertices), cheeseVertices, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //-------------------------------------------------------

    glBindVertexArray(boardVAO);

    glBindBuffer(GL_ARRAY_BUFFER, boardVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(boardVertices), boardVertices, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //--------------------------------------------------------

    glBindVertexArray(cucumberVAO);

    glBindBuffer(GL_ARRAY_BUFFER, cucumberVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(cucumberVertices), cucumberVertices, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //---------------------------------------------------------

    glBindVertexArray(cucumberSkinVAO);

    glBindBuffer(GL_ARRAY_BUFFER, cucumberSkinVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(cucumberSkinVert), cucumberSkinVert, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //------------------------------------------------------

    glBindVertexArray(knifeHandleVAO);

    glBindBuffer(GL_ARRAY_BUFFER, knifeHandleVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(knifeHandleVerts), knifeHandleVerts, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //-----------------------------------------------------

    glBindVertexArray(knifeBladeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, knifeBladeVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(knifeBladeVerts), knifeBladeVerts, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //----------------------------------------------------------

    glBindVertexArray(sphereVAO);

    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(sphereVerts), sphereVerts, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //----------------------------------------------------------

    glBindVertexArray(leafVAO);

    glBindBuffer(GL_ARRAY_BUFFER, leafVBO); // select VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(leafVerts), leafVerts, GL_STATIC_DRAW); // load vertex attributes, type size data and draw

    /* specify attribute location and layout to gpu */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    /* for color */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(3 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(1);

    // for our textures
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(6 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GL_FLOAT), (GLvoid*)(8 * sizeof(GL_FLOAT)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // closing it off

    //---------------------------------------------------

    GLuint lampVBO, lampVAO;

    glGenBuffers(1, &lampVBO);
    glGenVertexArrays(1, &lampVAO);

    glBindVertexArray(lampVAO);

    glBindBuffer(GL_ARRAY_BUFFER, lampVBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof(lampVertices), lampVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GL_FLOAT), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);

    //--------------------------------------------------------------------------------------------------------------------------------------

    // Load Textures
    int cheeseTexWidth, cheeseTexHeight, woodTexWidth, woodTexHeight, cucumberTexWidth, cucumberTexHeight, cucumberSkinTexWidth, cucumberSkinTexHeight, knifeHandleTexWidth, knifeHandleTexHeight, knifeBladeTexWidth, knifeBladeTexHeight, sphereTexWidth, sphereTexHeight, leafTexWidth, leafTexHeight;
    unsigned char* cheeseImage = SOIL_load_image("cheese.jpg", &cheeseTexWidth, &cheeseTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* woodImage = SOIL_load_image("wood.jpg", &woodTexWidth, &woodTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* cucumberImage = SOIL_load_image("cucumber.png", &cucumberTexWidth, &cucumberTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* cucumberSkinImage = SOIL_load_image("cucumberSkin.png", &cucumberSkinTexWidth, &cucumberSkinTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* knifeHandleImage = SOIL_load_image("handle.png", &knifeHandleTexWidth, &knifeHandleTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* knifeBladeImage = SOIL_load_image("blade.png", &knifeBladeTexWidth, &knifeBladeTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* sphereImage = SOIL_load_image("red.png", &sphereTexWidth, &sphereTexHeight, 0, SOIL_LOAD_RGB);
    unsigned char* leafImage = SOIL_load_image("leaf.png", &leafTexWidth, &leafTexHeight, 0, SOIL_LOAD_RGB);

    // Generate Textures
    GLuint cheeseTexture;
    glGenTextures(1, &cheeseTexture);
    glBindTexture(GL_TEXTURE_2D, cheeseTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cheeseTexWidth, cheeseTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cheeseImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(cheeseImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint woodTexture;
    glGenTextures(1, &woodTexture);
    glBindTexture(GL_TEXTURE_2D, woodTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, woodTexWidth, woodTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, woodImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(woodImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint cucumberTexture;
    glGenTextures(1, &cucumberTexture);
    glBindTexture(GL_TEXTURE_2D, cucumberTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cucumberTexWidth, cucumberTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cucumberImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(cucumberImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint cucumberSkinTexture;
    glGenTextures(1, &cucumberSkinTexture);
    glBindTexture(GL_TEXTURE_2D, cucumberSkinTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cucumberSkinTexWidth, cucumberSkinTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cucumberSkinImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(cucumberSkinImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint knifeHandleTexture;
    glGenTextures(1, &knifeHandleTexture);
    glBindTexture(GL_TEXTURE_2D, knifeHandleTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, knifeHandleTexWidth, knifeHandleTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, knifeHandleImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(knifeHandleImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint knifeBladeTexture;
    glGenTextures(1, &knifeBladeTexture);
    glBindTexture(GL_TEXTURE_2D, knifeBladeTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, knifeBladeTexWidth, knifeBladeTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, knifeBladeImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(knifeBladeImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint sphereTexture;
    glGenTextures(1, &sphereTexture);
    glBindTexture(GL_TEXTURE_2D, sphereTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, sphereTexWidth, sphereTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, sphereImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(sphereImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Generate Textures
    GLuint leafTexture;
    glGenTextures(1, &leafTexture);
    glBindTexture(GL_TEXTURE_2D, leafTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, leafTexWidth, leafTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, leafImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(leafImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    //-------------------------------------------------------------------------------------------------------------------

    glEnable(GL_DEPTH_TEST);

    /* vertex shader source code---when color information is added the shaders need to be updated */
    string vertexShaderSource =
        "#version 330 core\n"
        "layout(location = 0) in vec3 vPosition;"
        "layout(location = 1) in vec3 aColor;" // added for color attributes
        "layout(location = 2) in vec2 texCoord;"
        "layout(location = 3) in vec3 normal;"
        "out vec3 oColor;" // added for color attributes
        "out vec2 oTexCoord;"
        "out vec3 oNormal;"
        "out vec3 fragPos;"
        "uniform mat4 model;" // matrix
        "uniform mat4 view;"  // matrix
        "uniform mat4 projection;" // matrix
        "void main()\n"
        "{\n"
        "gl_Position = projection * view * model * vec4(vPosition, 1.0f);" // matrix multiplication to get our model view projection matrix
        "oColor = aColor;"  // added for color attributes
        "oTexCoord = texCoord;"
        "oNormal = mat3(transpose(inverse(model))) * normal;"
        "fragPos = vec3(model * vec4(vPosition, 1.0f));"
        "}\n";

    /* fragment shader source code */
    string fragmentShaderSource =
        "#version 330 core\n"
        "in vec3 oColor;"  // added for color attributes
        "in vec2 oTexCoord;"
        "in vec3 oNormal;"
        "in vec3 fragPos;"
        "out vec4 fragColor;"
        "uniform sampler2D myTexture;"
        "uniform vec3 objectColor;"
        "uniform vec3 lightColor;"
        "uniform vec3 lightPos;"
        "uniform vec3 viewPos;"
        "void main()\n"
        "{\n"
        "//Ambient\n"
        "float ambientStrength = 2.0f;"
        "vec3 ambient = ambientStrength * lightColor;"
        "//Diffuse\n"
        "vec3 norm = normalize(oNormal);"
        "vec3 lightDir = normalize(lightPos - fragPos);"
        "float diff = max(dot(norm, lightDir), 0.1);"
        "vec3 diffuse = diff * lightColor;"
        "//Specularity\n"
        "float specularStrength = 5.0f;"
        "vec3 viewDir = normalize(viewPos - fragPos);"
        "vec3 reflectDir = reflect(-lightDir, norm);"
        "float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);"
        "vec3 specular = specularStrength * spec * lightColor;"
        "vec3 result = (specular + ambient + diffuse) * objectColor;"
        "fragColor = texture(myTexture, oTexCoord) * vec4(result, 1.0);" // added for color attributes
        "}\n";

    //----------------------------------------------

    // shader for the lamp
    string lampVertexShaderSource =
        "#version 330 core\n"
        "layout(location = 0) in vec3 vPosition;"
        "uniform mat4 model;"
        "uniform mat4 view;"
        "uniform mat4 projection;"
        "void main()\n"
        "{\n"
        "gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
        "}\n";

    string lampFragmentShaderSource =
        "#version 330 core\n"
        "out vec4 fragColor;"
        "void main()\n"
        "{\n"
        "fragColor = vec4(1.0f);"
        "}\n";

    //--------------------------------------------------------------------------------------------------------------------------------------

    // Creating shader program
    GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
    GLuint lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);

    fov = 90;

    //--------------------------------------------------------------------------------------------------------------------------------------

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {

        // per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // Process input
        processInput(window);

        /* Render here */
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //--------------------------------------------------------------------------------------------------------------------------------------

        // model matrix 
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::rotate(model, glm::radians(0.1f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(2.0f, 2.0f, 2.0f));
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));

        // view matrix
        glm::mat4 view = glm::mat4(1.0f);
        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

        // projection matrix
        glm::mat4 projection;
        projection = glm::perspective(glm::radians(fov), 2160.0f / 1440.0f, 0.1f, 100.0f);

        // sending the matrices to the shader
        glUseProgram(shaderProgram);
        unsigned int modelLoc = glGetUniformLocation(shaderProgram, "model");
        unsigned int viewLoc = glGetUniformLocation(shaderProgram, "view");
        unsigned int projectionLoc = glGetUniformLocation(shaderProgram, "projection");

        GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
        GLint lightPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
        GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");


        glUniform3f(objectColorLoc, 0.5f,0.5f, 0.5f);
        glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
        glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);
        glUniform3f(viewPosLoc, cameraPos.x, cameraPos.y, cameraPos.z);

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

        //--------------------------------------------------------------------------------------------------------------------------------------

        glBindTexture(GL_TEXTURE_2D, woodTexture);

        glBindVertexArray(boardVAO);

        draw();

        glBindVertexArray(0); // deactivate in every frame

        //-------------------------------------------------

        glBindTexture(GL_TEXTURE_2D, cheeseTexture);

        glBindVertexArray(cheeseVAO); // activate in every frame

        model = glm::rotate(model, glm::radians(-14.0f), glm::vec3(0.0f, 2.0f, 0.0f));
        unsigned int modelLoc2 = glGetUniformLocation(shaderProgram, "model");
        glUniformMatrix4fv(modelLoc2, 1, GL_FALSE, glm::value_ptr(model));

        // Draw triangle
        draw();

        glBindVertexArray(0); // deactivate in every frame

        //------------------------------------------------
        glBindTexture(GL_TEXTURE_2D, cucumberTexture);

        glBindVertexArray(cucumberVAO);

        model = glm::scale(model, glm::vec3(0.15f, 0.15f, 0.15f));
        model = glm::translate(model, glm::vec3(0.0f, 1.0f, 0.0f));

        for (GLuint i = 0; i < 10; i++) {

            model = glm::rotate(model, glm::radians(-36.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            unsigned int modelLoc3 = glGetUniformLocation(shaderProgram, "model");
            glUniformMatrix4fv(modelLoc3, 1, GL_FALSE, glm::value_ptr(model));

            draw();

        }

        glBindVertexArray(0);

        //-------------------------------------------------

        glBindTexture(GL_TEXTURE_2D, cucumberSkinTexture);

        glBindVertexArray(cucumberSkinVAO);

        for (GLuint i = 0; i < 10; i++) {

            model = glm::rotate(model, glm::radians(-36.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            unsigned int modelLoc4 = glGetUniformLocation(shaderProgram, "model");
            glUniformMatrix4fv(modelLoc4, 1, GL_FALSE, glm::value_ptr(model));

            draw();

        }

        glBindVertexArray(0);

        //---------------------------------------------------

        glBindVertexArray(knifeHandleVAO);

        glBindTexture(GL_TEXTURE_2D, knifeHandleTexture);

        model = glm::rotate(model, glm::radians(-34.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
        model = glm::translate(model, glm::vec3(5.0f, -0.7f, 4.0f));
        unsigned int modelLoc5 = glGetUniformLocation(shaderProgram, "model");
        glUniformMatrix4fv(modelLoc5, 1, GL_FALSE, glm::value_ptr(model));

        draw();

        glBindVertexArray(0); // deactivate in every frame

        //---------------------------------------------------

        glBindVertexArray(knifeBladeVAO);

        glBindTexture(GL_TEXTURE_2D, knifeBladeTexture);

        model = glm::rotate(model, glm::radians(0.01f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
        model = glm::translate(model, glm::vec3(0.0f, 0.01f, 0.0f));
        unsigned int modelLoc6 = glGetUniformLocation(shaderProgram, "model");
        glUniformMatrix4fv(modelLoc6, 1, GL_FALSE, glm::value_ptr(model));

        draw();

        glBindVertexArray(0); // deactivate in every frame

        //------------------------------------------------------

        glBindTexture(GL_TEXTURE_2D, sphereTexture);
        //glBindTexture(GL_TEXTURE_2D, woodTexture);

        glBindVertexArray(sphereVAO);

        for (GLuint k = 0; k < 1; k++) {

            model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
            model = glm::translate(model, glm::vec3(10.0f, 0.0f, -18.0f));
            unsigned int modelLoc7 = glGetUniformLocation(shaderProgram, "model");

            // rotate ring to form a sphere
            for (GLuint j = 0; j < 20; j++) {

                model = glm::rotate(model, glm::radians(-150.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                glUniformMatrix4fv(modelLoc7, 1, GL_FALSE, glm::value_ptr(model));

                draw();

                // draw a single ring of pyramids
                for (GLuint i = 0; i < 20; i++)
                {
                    model = glm::rotate(model, glm::radians(-22.5f), glm::vec3(0.0f, 0.0f, 1.0f));
                    model = glm::translate(model, glm::vec3(-0.77f, -0.153f, 0.0f));
                    //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
                    glUniformMatrix4fv(modelLoc7, 1, GL_FALSE, glm::value_ptr(model));

                    draw();
                }
            }
        }

        glBindVertexArray(0); // deactivate in every frame

        //--------------------------------------

        glBindTexture(GL_TEXTURE_2D, sphereTexture);
        //glBindTexture(GL_TEXTURE_2D, woodTexture);

        glBindVertexArray(sphereVAO);

        for (GLuint k = 0; k < 1; k++) {

            model = glm::scale(model, glm::vec3(1.2f, 1.2f, 1.2f));
            model = glm::translate(model, glm::vec3(0.0f, 4.0f, -4.0f));
            unsigned int modelLoc8 = glGetUniformLocation(shaderProgram, "model");

            // rotate ring to form a sphere
            for (GLuint j = 0; j < 20; j++) {

                model = glm::rotate(model, glm::radians(-150.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                glUniformMatrix4fv(modelLoc8, 1, GL_FALSE, glm::value_ptr(model));

                draw();

                // draw a single ring of pyramids
                for (GLuint i = 0; i < 20; i++)
                {
                    model = glm::rotate(model, glm::radians(-22.5f), glm::vec3(0.0f, 0.0f, 1.0f));
                    model = glm::translate(model, glm::vec3(-0.77f, -0.153f, 0.0f));
                    //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
                    glUniformMatrix4fv(modelLoc8, 1, GL_FALSE, glm::value_ptr(model));

                    draw();
                }
            }
        }

        glBindVertexArray(0); // deactivate in every frame

        //--------------------------------------

        glBindTexture(GL_TEXTURE_2D, sphereTexture);
        //glBindTexture(GL_TEXTURE_2D, woodTexture);

        glBindVertexArray(sphereVAO);

        for (GLuint k = 0; k < 1; k++) {

            model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
            model = glm::translate(model, glm::vec3(-5.0f, -1.0f, -4.0f));
            unsigned int modelLoc9 = glGetUniformLocation(shaderProgram, "model");

            // rotate ring to form a sphere
            for (GLuint j = 0; j < 20; j++) {

                model = glm::rotate(model, glm::radians(-150.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                glUniformMatrix4fv(modelLoc9, 1, GL_FALSE, glm::value_ptr(model));

                draw();

                // draw a single ring of pyramids
                for (GLuint i = 0; i < 20; i++)
                {
                    model = glm::rotate(model, glm::radians(-22.5f), glm::vec3(0.0f, 0.0f, 1.0f));
                    model = glm::translate(model, glm::vec3(-0.77f, -0.153f, 0.0f));
                    //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
                    glUniformMatrix4fv(modelLoc9, 1, GL_FALSE, glm::value_ptr(model));

                    draw();
                }
            }
        }

        glBindVertexArray(0); // deactivate in every frame

        //--------------------------------------

        glBindTexture(GL_TEXTURE_2D, leafTexture);

        glBindVertexArray(leafVAO);

        model = glm::translate(model, glm::vec3(-2.6f, 1.8f, 0.5f));
        model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, .0f));

        for (GLuint i = 0; i < 3; i++)
        {
            model = glm::rotate(model, glm::radians(-110.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::translate(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
            unsigned int modelLoc10 = glGetUniformLocation(shaderProgram, "model");
            glUniformMatrix4fv(modelLoc10, 1, GL_FALSE, glm::value_ptr(model));
            

            draw();
        }

        glBindVertexArray(0); // deactivate in every frame

        //--------------------------------------

        glBindTexture(GL_TEXTURE_2D, leafTexture);

        glBindVertexArray(leafVAO);

        model = glm::translate(model, glm::vec3(1.6f, -4.8f, -1.0f));
        model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, .0f));

        for (GLuint i = 0; i < 3; i++)
        {
            model = glm::rotate(model, glm::radians(-110.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::translate(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
            unsigned int modelLoc10 = glGetUniformLocation(shaderProgram, "model");
            glUniformMatrix4fv(modelLoc10, 1, GL_FALSE, glm::value_ptr(model));


            draw();
        }

        glBindVertexArray(0); // deactivate in every frame

        //--------------------------------------

        glBindTexture(GL_TEXTURE_2D, leafTexture);

        glBindVertexArray(leafVAO);

        model = glm::translate(model, glm::vec3(-4.1f, 3.0f, 2.5f));
        model = glm::rotate(model, glm::radians(-5.0f), glm::vec3(0.0f, 1.0f, .0f));

        for (GLuint i = 0; i < 3; i++)
        {
            model = glm::rotate(model, glm::radians(-110.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::translate(model, glm::vec3(1.0f, 1.0f, 1.0f));
            //model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
            unsigned int modelLoc10 = glGetUniformLocation(shaderProgram, "model");
            glUniformMatrix4fv(modelLoc10, 1, GL_FALSE, glm::value_ptr(model));


            draw();
        }

        glBindVertexArray(0); // deactivate in every frame

        glUseProgram(0);

        //--------------------------------------

        glUseProgram(lampShaderProgram);

        GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
        GLint lampViewLoc = glGetUniformLocation(lampShaderProgram, "view");
        GLint lampProjectionLoc = glGetUniformLocation(lampShaderProgram, "projection");

        glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(lampProjectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

        glBindVertexArray(lampVAO);

        model = glm::translate(model, lightPosition);
        model = glm::scale(model, glm::vec3(2.0f, 2.0f, 2.0f));
        glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(model));

        draw();

        glBindVertexArray(0); // deactivate in every frame
        glUseProgram(0);

        //-------------------------------------------------------------------------------

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}

// glfw: whenever the mouse moves, this callback is called
//--------------------------------------------------------------------------------------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
//--------------------------------------------------------------------------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    fov -= (float)yoffset;
    if (fov < 1.0f)
        fov = 1.0f;
    if (fov > 45.0f)
        fov = 45.0f;
}